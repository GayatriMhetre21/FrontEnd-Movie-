import type { Movie } from "../types"

const movies: Movie[] = [
  {
    id: 1,
    title: "Inception",
    year: 2010,
    poster: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg",
    category: "Hollywood",
  },
  {
    id: 2,
    title: "The Dark Knight",
    year: 2008,
    poster: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_SX300.jpg",
    category: "Hollywood",
  },
  {
    id: 3,
    title: "Dilwale Dulhania Le Jayenge",
    year: 1995,
    poster:
      "https://m.media-amazon.com/images/M/MV5BOTIyNDIwYjgtNGQ3ZC00OWNiLWE3MTYtZjE4YjZjOWVmNTFkXkEyXkFqcGdeQXVyNjQ2MjQ5NzM@._V1_SX300.jpg",
    category: "Bollywood",
  },
  {
    id: 4,
    title: "3 Idiots",
    year: 2009,
    poster:
      "https://m.media-amazon.com/images/M/MV5BNTkyOGVjMGEtNmQzZi00NzFlLTlhOWQtODYyMDc2ZGJmYzFhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg",
    category: "Bollywood",
  },
  {
    id: 5,
    title: "Parasite",
    year: 2019,
    poster:
      "https://m.media-amazon.com/images/M/MV5BYWZjMjk3ZTItODQ2ZC00NTY5LWE0ZDYtZTI3MjcwN2Q5NTVkXkEyXkFqcGdeQXVyODk4OTc3MTY@._V1_SX300.jpg",
    category: "Dual Audio",
  },
  // Add more movies here...
]

export async function getMovies(
  page = 1,
  limit = 10,
  search = "",
  category = "",
): Promise<{ movies: Movie[]; total: number }> {
  let filteredMovies = movies

  if (search) {
    filteredMovies = filteredMovies.filter((movie) => movie.title.toLowerCase().includes(search.toLowerCase()))
  }

  if (category && category !== "All") {
    filteredMovies = filteredMovies.filter((movie) => movie.category === category)
  }

  const total = filteredMovies.length
  const start = (page - 1) * limit
  const end = start + limit

  return {
    movies: filteredMovies.slice(start, end),
    total,
  }
}

