"use client"

import { useState, useEffect } from "react"
import Navbar from "../components/Navbar"
import MovieGrid from "../components/MovieGrid"
import { getMovies } from "../lib/api"
import type { Movie } from "../types"

export default function Home() {
  const [movies, setMovies] = useState<Movie[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalMovies, setTotalMovies] = useState(0)
  const [search, setSearch] = useState("")
  const [category, setCategory] = useState("All")

  useEffect(() => {
    const fetchMovies = async () => {
      setLoading(true)
      try {
        const { movies: fetchedMovies, total } = await getMovies(page, 10, search, category)
        setMovies(fetchedMovies)
        setTotalMovies(total)
      } catch (error) {
        console.error("Error fetching movies:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMovies()
  }, [page, search, category])

  const handleSearch = (query: string) => {
    setSearch(query)
    setPage(1)
  }

  const handleCategoryChange = (newCategory: string) => {
    setCategory(newCategory)
    setPage(1)
  }

  return (
    <main className="min-h-screen bg-gray-900 text-white">
      <Navbar onSearch={handleSearch} onCategoryChange={handleCategoryChange} />
      <div className="container mx-auto px-4 py-8">
        <MovieGrid movies={movies} loading={loading} page={page} totalMovies={totalMovies} onPageChange={setPage} />
      </div>
    </main>
  )
}

