import MovieCard from "./MovieCard"
import type { Movie } from "../types"

interface MovieGridProps {
  movies: Movie[]
  loading: boolean
  page: number
  totalMovies: number
  onPageChange: (page: number) => void
}

export default function MovieGrid({ movies, loading, page, totalMovies, onPageChange }: MovieGridProps) {
  const totalPages = Math.ceil(totalMovies / 10)

  if (loading) {
    return <div className="text-center py-10">Loading...</div>
  }

  if (movies.length === 0) {
    return <div className="text-center py-10">No movies found.</div>
  }

  return (
    <>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
      <div className="flex justify-center mt-8">
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-l disabled:opacity-50"
        >
          Previous
        </button>
        <span className="bg-gray-700 text-white font-bold py-2 px-4">
          Page {page} of {totalPages}
        </span>
        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page === totalPages}
          className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-r disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </>
  )
}

