"use client"

import type React from "react"

import { useState } from "react"
import { Search } from "lucide-react"

interface NavbarProps {
  onSearch: (query: string) => void
  onCategoryChange: (category: string) => void
}

export default function Navbar({ onSearch, onCategoryChange }: NavbarProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    onSearch(searchQuery)
  }

  return (
    <nav className="bg-gray-800 shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-4">
            <button
              className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              onClick={() => onCategoryChange("All")}
            >
              All
            </button>
            <button
              className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              onClick={() => onCategoryChange("Bollywood")}
            >
              Bollywood
            </button>
            <button
              className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              onClick={() => onCategoryChange("Hollywood")}
            >
              Hollywood
            </button>
            <button
              className="text-gray-300 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              onClick={() => onCategoryChange("Dual Audio")}
            >
              Dual Audio
            </button>
          </div>
          <div className="flex items-center space-x-4">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                placeholder="Search movies..."
                className="bg-gray-700 text-white rounded-full py-2 px-4 pl-10 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </form>
            <a
              href="https://t.me/your_telegram_channel"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded"
            >
              Join Telegram
            </a>
          </div>
        </div>
      </div>
    </nav>
  )
}

