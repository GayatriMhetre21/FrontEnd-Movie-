import Image from "next/image"
import type { Movie } from "../types"

interface MovieCardProps {
  movie: Movie
}

export default function MovieCard({ movie }: MovieCardProps) {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105">
      <Image
        src={movie.poster || "/placeholder.svg"}
        alt={movie.title}
        width={300}
        height={450}
        className="w-full h-auto"
      />
      <div className="p-4">
        <p className="text-sm text-gray-400 mb-1">{movie.year}</p>
        <h3 className="text-lg font-semibold mb-2 group-hover:text-blue-400 transition-colors duration-300">
          {movie.title}
        </h3>
        <p className="text-sm text-gray-400 mb-2">{movie.category}</p>
        <div className="flex space-x-2">
          <button className="bg-blue-500 hover:bg-blue-600 text-white text-xs px-2 py-1 rounded">1080p</button>
          <button className="bg-green-500 hover:bg-green-600 text-white text-xs px-2 py-1 rounded">720p</button>
          <button className="bg-yellow-500 hover:bg-yellow-600 text-white text-xs px-2 py-1 rounded">480p</button>
        </div>
      </div>
    </div>
  )
}

